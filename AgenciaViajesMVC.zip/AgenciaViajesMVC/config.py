class Config:
    SECRET_KEY="clave"
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '1234'
    MYSQL_DB = 'AgenciaViajes'
    SESSION_COOKIE_SECURE: False
