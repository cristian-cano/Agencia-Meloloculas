from flask import Blueprint, render_template

main = Blueprint('main', __name__)

@main.route('/proveedor/actualizar')
def    actualizar():
    return render_template('proveedor/actualizar.html')