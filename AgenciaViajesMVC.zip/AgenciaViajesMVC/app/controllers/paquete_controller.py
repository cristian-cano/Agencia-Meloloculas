from flask import Blueprint, render_template, request, redirect, url_for, current_app
import pymysql

paquete = Blueprint('paquete', __name__, url_prefix='/paquetes')

def get_db_connection():
    return pymysql.connect(
        host=current_app.config['MYSQL_HOST'],
        user=current_app.config['MYSQL_USER'],
        password=current_app.config['MYSQL_PASSWORD'],
        database=current_app.config['MYSQL_DB'],
        cursorclass=pymysql.cursors.DictCursor
    )

@paquete.route('/agregar', methods=['GET'])
def formulario_paquete():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT id, nombre FROM hoteles")
        hoteles = cursor.fetchall()
        cursor.execute("SELECT id, numero_vuelo FROM vuelos")
        vuelos = cursor.fetchall()
    conn.close()
    return render_template('agregar.html', hoteles=hoteles, vuelos=vuelos)

@paquete.route('/guardar', methods=['POST'])
def guardar_paquete():
    nombre = request.form['nombre']
    descripcion = request.form['descripcion']
    precio = float(request.form['precio'])
    hotel_id = int(request.form['hotel_id'])
    vuelo_id = int(request.form['vuelo_id'])

    conn = get_db_connection()
    with conn.cursor() as cursor:
        sql = """
            INSERT INTO paquetes (nombre, descripcion, precio_total, hotel_id, vuelo_id)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (nombre, descripcion, precio, hotel_id, vuelo_id))
        conn.commit()
    conn.close()
    return redirect(url_for('main.index'))