from flask import Blueprint, render_template
proveedor = Blueprint('proveedor_bp', __name__, url_prefix='/proveedor')

@proveedor.route('/')
def vista_proveedor():
    return render_template('proveedor.html')
