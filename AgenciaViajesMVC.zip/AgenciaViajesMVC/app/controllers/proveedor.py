from flask import Blueprint, render_template

proveedor = Blueprint ('proveedor', __name__, url_prefix='/proveedor')

@proveedor.route('/')
def panel_proveedor():
    render_template = ('proveedor.html')
