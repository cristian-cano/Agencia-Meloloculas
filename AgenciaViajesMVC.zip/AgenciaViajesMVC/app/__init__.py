from flask import Flask
import pymysql.cursors
from config import Config

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    connection = pymysql.connect(
        host = app.config['MYSQL_HOST'],
        user = app.config['MYSQL_USER'],
        password = app.config['MYSQL_PASSWORD'],
        database = app.config['MYSQL_DB'],
        cursorclass = pymysql.cursors.DictCursor
    )

    from app.controllers.main_controller import main
    app.register_blueprint(main)

    from app.controllers.paquete_controller import paquete
    app.register_blueprint(paquete)

    from app.controllers.proveedor_controller import proveedor
    app.register_blueprint(proveedor)

    return app  